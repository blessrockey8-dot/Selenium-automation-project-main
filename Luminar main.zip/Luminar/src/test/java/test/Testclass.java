package test;

import org.testng.annotations.Test;

import base.Baseclass;
import page.Pageclass;

public class Testclass extends Baseclass {
	@Test
	public void testk() {
		
	
	Pageclass ob = new Pageclass(driver);
	
	ob.title();
	ob.enrollnw();
	ob.setvalues("killua", "kk@gmail.com", "00000000", "kiii island", "Am intrested in ur website");
	ob.dropdown();
	ob.button();
	ob.Url();
	}
}
