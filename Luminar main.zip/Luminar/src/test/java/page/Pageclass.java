package page;

import java.awt.List;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import base.Baseclass;

public class  Pageclass extends Baseclass {
	WebDriver driver;
	Actions act;
	WebDriverWait wait;
	
	@FindBy(xpath="/html/body/div[1]/div[1]/div[1]/div/div[2]/div[4]/div[1]/a")
	WebElement enrollnow;
	@FindBy(xpath ="//*[@id=\"first-name\"]" )
	WebElement name;
	@FindBy(xpath = "//*[@id=\"email\"]")
	WebElement email;
	@FindBy(xpath ="//*[@id=\"mobile\"]")
	WebElement number;
	@FindBy(xpath = "//*[@id=\"city\"]")
	WebElement city;
	@FindBy(xpath ="//*[@id=\"message\"]")
	WebElement message;
	@FindBy(xpath="/html/body/div[1]/div[5]/div/div[3]/form/button")
	WebElement button;
	@FindBy(xpath="/html/body/div[1]/div[5]/div/div[3]/form/div[5]/select")
	WebElement dropdown;

	public Pageclass(WebDriver driver ) {
		this.driver = driver;
		this.act=new Actions (driver);
		
		this.wait = new WebDriverWait(driver,Duration.ofSeconds(30));
		PageFactory.initElements(driver, this);
		
		
	}
//	public void checkBrokenLinks() throws Exception {
//
//	    List<WebElement> links = driver.findElements(By.tagName("a"));
//
//
//	        URL linkUrl = new URL(url);
//	        HttpURLConnection connection =
//	                (HttpURLConnection) linkUrl.openConnection();
//
//	      
//
//	        int responseCode = connection.getResponseCode();
//
//	        if (responseCode >= 400) {
//	            System.out.println(url + "broken");
//	        } else {
//	            System.out.println(url + "working");
//	        }
	    


	public void title() {
		String exp ="Tools QA";
		String act = driver.getTitle();
		System.out.println(act);
Assert.assertEquals(exp, act);
	}
	public void enrollnw() {
		enrollnow.click();
	}
	public void setvalues(String killua,String ki,String ph,String loc,String mes) {
	name.sendKeys(killua);
	email.sendKeys(ki);
	number.sendKeys(ph);
	city.sendKeys(loc);
	message.sendKeys(mes);


	}
	public void dropdown() {

	        Select select = new Select(dropdown);
	        select.selectByValue("194");
	    }

	

	public void button() {
		button.click();
		
	}
	public void Url() {
		String expectedUrl = "https://www.toolsqa.com/";
		String actualUrl = driver.getCurrentUrl();
System.out.println(actualUrl);
		Assert.assertEquals(actualUrl, expectedUrl);
	}
	
		
		
		
		
	}
	
	


